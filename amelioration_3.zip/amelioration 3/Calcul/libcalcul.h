/** fichier libcalcul.h **/
#ifndef H_LIBCALCUL
#define H_LIBCALCUL
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <string.h>
#include <dirent.h>


int count_files(char *repertoire) ;

int find_exped(char *fileName,char *strSearch) ;



#endif
